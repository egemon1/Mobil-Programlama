package com.example.notlarim;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.io.Serializable;

@Entity(tableName = "notes")
public class Note implements Serializable {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String title;
    public String content;
    public String date;
    public String imageUri;
    public long timestamp; // Gerçek zamanlı sıralama için

    public Note(String title, String content, String date, String imageUri, long timestamp) {
        this.title = title;
        this.content = content;
        this.date = date;
        this.imageUri = imageUri;
        this.timestamp = timestamp;
    }
}
